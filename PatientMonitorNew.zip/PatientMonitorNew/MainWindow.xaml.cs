﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using Microsoft.Win32;

using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.DataVisualization.Charting;
using System.Windows.Controls.DataVisualization.Charting.Compatible;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;


namespace PatientMonitor
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ObservableCollection<KeyValuePair<int, double>> dataPoints;
        private DispatcherTimer timer;
        private int index = 0;
        Patient patient;
        MRImages anImage;
        MonitorConstants.Parameter parameter = MonitorConstants.Parameter.ECG;

        public MainWindow()
        {
            InitializeComponent();
            sliderECG.Value = 0;
            ComboBoxHarmonics.Text = "1";
            TextBoxFrequency.Text = " ";

            dataPoints = new ObservableCollection<KeyValuePair<int, double>>();
            lineSeriesECG.ItemsSource = dataPoints;
            patient = new Patient(100, (double)1.0, 1, "John Doe", DateTime.Now, 1, anImage, 1.0, 1.0);

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(0.025); // Set timer to tick every second
            timer.Tick += Timer_Tick;

        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            // Generate a new data point
            dataPoints.Add(new KeyValuePair<int, double>(index++, patient.NextSample(index, parameter)));

            // Optional: Remove old points to keep the chart clean
            if (dataPoints.Count > 200) // Maximum number of points
            {
                dataPoints.RemoveAt(0); // Remove the oldest point
            }
        }

        private void Slider_IsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            Slider slider = sender as Slider;
            if (slider.IsEnabled) slider.ValueChanged += sliderECG_ValueChanged;
            else slider.ValueChanged -= sliderECG_ValueChanged;
        }

        private void sliderECG_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            switch (parameter)
            {

                case (MonitorConstants.Parameter.ECG):
                    patient.ECGAmplitude = sliderECG.Value;
                    break;
                case (MonitorConstants.Parameter.EMG):
                    patient.EMGAmplitude = sliderECG.Value;
                    break;
                case (MonitorConstants.Parameter.EEG):
                    patient.EEGAmplitude = sliderECG.Value;
                    break;
                case (MonitorConstants.Parameter.Resp):
                    patient.RespAmplitude = sliderECG.Value;
                    break;
                default:
                    break;


            }

        }





        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }



        private void ButtonUpdatePatient_Click(object sender, RoutedEventArgs e)
        {

        }


        /*private void TextBoxFrequency_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (patient != null)
            {
                int parameterFreq = 0;
                bool isValidFreq;
                isValidFreq = int.TryParse(TextBoxFrequency.Text, out parameterFreq);

                parameterFreq = isValidFreq ? parameterFreq : 0;
                //parameterFreq /= 10; 

                if (isValidFreq)
                {
                    // Überprüfen, ob der Wert im zulässigen Bereich liegt
                    if (parameterFreq < 0 || parameterFreq > 150.0)
                    {
                        MessageBox.Show("Please enter a value not greater than 150 Hz or less than 0 !");
                    }
                    else
                    {
                        switch (parameter)
                        {
                            case (MonitorConstants.Parameter.ECG):
                                patient.ECGFrequency = (double)parameterFreq;
                                patient.HighAlarm(parameter, patient.ECGHighAlarm);
                                patient.LowAlarm(parameter, patient.ECGLowAlarm);
                                break;
                            case (MonitorConstants.Parameter.EEG):
                                patient.EEGFrequency = (double)parameterFreq;
                                patient.HighAlarm(parameter, patient.EEGHighAlarm);
                                patient.LowAlarm(parameter, patient.EEGLowAlarm);
                                break;
                            case (MonitorConstants.Parameter.EMG):
                                patient.EMGFrequency = (double)parameterFreq;
                                patient.HighAlarm(parameter, patient.EMGHighAlarm);
                                patient.LowAlarm(parameter, patient.EMGLowAlarm);
                                break;
                            case (MonitorConstants.Parameter.Resp):
                                patient.RespFrequency = (double)parameterFreq;
                                patient.HighAlarm(parameter, patient.RespHighAlarm);
                                patient.LowAlarm(parameter, patient.RespLowAlarm);
                                break;
                            default: break;
                        }
                        DisplayAlarmLow.Content = patient.DisplayedLowAlarm;
                        DisplayAlarmHigh.Content = patient.DisplayedHighAlarm;
                    }
                }
                else
                {
                    if (isValidFreq == false)
                        MessageBox.Show("Please enter a valid Parameter Frequency");
                }


            }



        }*/
        private void TextBoxFrequency_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (patient == null) return;

            if (int.TryParse(TextBoxFrequency.Text, out int parameterFreq))
            {
                if (parameterFreq < 0 || parameterFreq > 150)
                {
                    MessageBox.Show("Please enter a value between 0 and 150 Hz.");
                    return;
                }

                switch (parameter)
                {
                    case MonitorConstants.Parameter.ECG:
                        patient.ECGFrequency = parameterFreq;
                        break;
                    case MonitorConstants.Parameter.EEG:
                        patient.EEGFrequency = parameterFreq;
                        break;
                    case MonitorConstants.Parameter.EMG:
                        patient.EMGFrequency = parameterFreq;
                        break;
                    case MonitorConstants.Parameter.Resp:
                        patient.RespFrequency = parameterFreq;
                        break;
                }

                int.TryParse(highAlarmTextBox.Text, out int highalarm);

                int.TryParse(lowAlarmTextBox.Text, out int lowalarm);   //Notfall Lösung: Anstatt den ActiveHigh und low alarm zu nehmen,nehmen wir einfach den jetzigen Inhalt von den TExtboxen
                // EIgentlich muss in der lowALarmTextBox_TextChanged der Wert für ActiveLowALarm angepasst werden, diese Lösung dauert aber jetzt zu lange

                // Update alarms
                patient.LowAlarm(parameter, lowalarm); 
                patient.HighAlarm(parameter, highalarm);
                

                // Update displayed alarms
                DisplayAlarmLowLabel.Content = patient.DisplayedLowAlarm;
                DisplayAlarmHighLabel.Content = patient.DisplayedHighAlarm;
            }
            else
            {
                MessageBox.Show("Invalid input. Please enter a numerical value.");
            }
        }




        private void TextBoxName_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void textBoxPatientName_TextChanged(object sender, TextChangedEventArgs e)
        {
            // textBoxPatientName.Text = "";
        }

        private void textBoxPatientName_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = int.TryParse(e.Text, out _);
        }

        private void textBoxPatientAge_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {

            e.Handled = !int.TryParse(e.Text, out int result);
        }

        private void datePickerMonitor_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            // Überprüfen, ob ein gültiges Datum ausgewählt wurde
            if (!datePickerMonitor.SelectedDate.HasValue)
            {
                // Zeigt eine Warnung, wenn kein Datum ausgewählt ist oder ein ungültiges Datum eingegeben wurde
                MessageBox.Show("Please select a valid date!", "Invalid Date", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
            {
                // Optional: Bestätigung, dass das Datum korrekt ist
                DateTime selectedDate = datePickerMonitor.SelectedDate.Value;
                // Hier kann weitere Logik hinzugefügt werden, z.B. das gewählte Datum verwenden
            }
        }

        private void datePickerMonitor_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {

        }





        private void textBoxPatientName_GotFocus(object sender, RoutedEventArgs e)
        {
            textBoxPatientName.Text = "";
        }

        private void ComboBoxHarmonics_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (patient != null && ComboBoxHarmonics.SelectedIndex >= 0)

            {
                patient.ECGHarmonics = ComboBoxHarmonics.SelectedIndex + 1;
            }
            else
                ComboBoxHarmonics.SelectedIndex = 0;
        }


        private void textBoxPatientAge_GotFocus(object sender, RoutedEventArgs e)
        {
            textBoxPatientAge.Text = " ";
        }

        private void buttonStartParameter_Click(object sender, RoutedEventArgs e)
        {
            sliderECG.IsEnabled = true;
            ComboBoxHarmonics.IsEnabled = true;
            TextBoxFrequency.IsEnabled = true;
            comboBoxParameters.IsEnabled = true;
            timer.Start();

        }

        private void buttonQuit_Click(object sender, RoutedEventArgs e)
        {
            timer.Stop();
        }

        private void buttonCreatePatient_Click(object sender, RoutedEventArgs e)
        {
            if (textBoxPatientName.Text == "Enter Name here" || string.IsNullOrWhiteSpace(textBoxPatientName.Text))
            {
                MessageBox.Show("Please enter a name!");
                return;
            }

            if (textBoxPatientAge.Text == "Enter Age here" || !int.TryParse(textBoxPatientAge.Text, out int age))
            {
                MessageBox.Show("Please enter a valid age!");
                return;
            }

            if (!datePickerMonitor.SelectedDate.HasValue)
            {
                MessageBox.Show("Please select a date!");
                return;
            }

            double frequency = 1;

            if (!int.TryParse(ComboBoxHarmonics.Text, out int harmonics))
            {
                MessageBox.Show("Please select a valid harmonics value.");
                return;
            }

            buttonStartParameter.IsEnabled = true;
            ButtonUpdatePatient.IsEnabled = true;
            buttonLoadImage.IsEnabled = true;

            patient = new Patient(sliderECG.Value, frequency, harmonics, textBoxPatientName.Text, datePickerMonitor.SelectedDate.Value, age, anImage, 0, 0);

        }




        private void TextBoxFrequency_KeyDown(object sender, KeyEventArgs e)
        {
            /* if (e.Key == Key.Enter)
             {
                 if (patient != null)
                 {
                     // Überprüfen, ob der Text in 'textBoxFrequency' in eine Zahl konvertiert werden kann
                     if (int.TryParse(TextBoxFrequency.Text, out int parameterFreq))
                     {
                         // Begrenze die Frequenz auf einen gültigen Bereich
                         if (parameterFreq > 0 && parameterFreq <= 150)
                         {
                             // Setze die Frequenz basierend auf dem aktuellen Parameter
                             switch (parameter)
                             {
                                 case MonitorConstants.Parameter.ECG:
                                     patient.ECGFrequency = (double)parameterFreq;
                                     patient.HighAlarm(parameter, patient.ECGHighAlarm);
                                     patient.LowAlarm(parameter, patient.ECGLowAlarm);
                                     break;
                                 case MonitorConstants.Parameter.EEG:
                                     patient.EEGFrequency = (double)parameterFreq;
                                     patient.HighAlarm(parameter, patient.EEGHighAlarm);
                                     patient.LowAlarm(parameter, patient.EEGLowAlarm);
                                     break;
                                 case MonitorConstants.Parameter.EMG:
                                     patient.EMGFrequency = (double)parameterFreq;
                                     patient.HighAlarm(parameter, patient.EMGHighAlarm);
                                     patient.LowAlarm(parameter, patient.EMGLowAlarm);
                                     break;
                                case MonitorConstants.Parameter.Resp:
                                     patient.RespFrequency = (double)parameterFreq;
                                     patient.HighAlarm(parameter, patient.RespHighAlarm);
                                     patient.LowAlarm(parameter, patient.RespLowAlarm);
                                     break;
                                 default:
                                     break;
                             }
                             DisplayAlarmLow.Content = patient.DislpayedLowAlarm;
                             DisplayAlarmHigh.Content = patient.DisplayedHighAlarm;
                         }
                         else
                         {
                             MessageBox.Show("Bitte geben Sie einen Wert zwischen 0 und 150 ein.");
                         }
                     }
                     else
                     {
                         MessageBox.Show("Ungültige Eingabe! Bitte geben Sie eine gültige Zahl ein.");
                     }
                 }
                 else
                 {
                     MessageBox.Show("Kein Patient ausgewählt.");
                 }
             }*/
        }








        /*private void comboBoxParameters_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            parameter = (MonitorConstants.Parameter)comboBoxParameters.SelectedIndex;
            TextBoxFrequency.IsEnabled = true;
            sliderECG.IsEnabled = true;
            // lowAlarmTextBox.IsEnabled = true;
            // highAlarmTextBox.IsEnabled = true;
            patient.HighAlarm(parameter, patient.ActiveHighAlarm);
            patient.LowAlarm(parameter, patient.ActiveLowAlarm);

            DisplayAlarmLow.Content = patient.DisplayedLowAlarm;
            DisplayAlarmHigh.Content = patient.DisplayedHighAlarm;
            Console.WriteLine($"[DEBUG] Parameter gewechselt: {parameter}");

            if (parameter == MonitorConstants.Parameter.ECG)
            {
                ComboBoxHarmonics.IsEnabled = true;
            }
            else
            {
               
                ComboBoxHarmonics.IsEnabled = false;
            }
            switch (parameter)
            {
                case MonitorConstants.Parameter.ECG: patient.setActiveParameters(patient.ECGFrequency, patient.ECGAmplitude, patient.ECGHarmonics,patient.ECGLowAlarm,patient.ECGHighAlarm);
                    break;
            
                case MonitorConstants.Parameter.EMG: patient.setActiveParameters(patient.EMGFrequency, patient.EMGAmplitude, -1 , patient.EMGLowAlarm, patient.EMGHighAlarm);
                    break;

                case MonitorConstants.Parameter.Resp: patient.setActiveParameters(patient.RespFrequency, patient.RespAmplitude, -1, patient.RespLowAlarm, patient.RespHighAlarm); 
                    break;

                case MonitorConstants.Parameter.EEG: patient.setActiveParameters(patient.EEGFrequency , patient.EEGAmplitude, -1, patient.EEGLowAlarm , patient.EEGHighAlarm);
                    break;

                default: 
                    break;
            }
            sliderECG.Value = patient.ActiveAmplitude;
            TextBoxFrequency.Text = patient.ActiveFrequency.ToString();
        
        }*/
        private void comboBoxParameters_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            parameter = (MonitorConstants.Parameter)comboBoxParameters.SelectedIndex;
            TextBoxFrequency.IsEnabled = true;
            sliderECG.IsEnabled = true;
            lowAlarmTextBox.IsEnabled = true;
            highAlarmTextBox.IsEnabled = true;

            // Set active parameters for the selected parameter type
            switch (parameter)
            {
                case MonitorConstants.Parameter.ECG:
                    patient.setActiveParameters(patient.ECGFrequency, patient.ECGAmplitude, patient.ECGHarmonics, patient.ECGLowAlarm, patient.ECGHighAlarm);
                    ComboBoxHarmonics.IsEnabled = true;
                    break;
                case MonitorConstants.Parameter.EEG:
                    patient.setActiveParameters(patient.EEGFrequency, patient.EEGAmplitude, -1, patient.EEGLowAlarm, patient.EEGHighAlarm);
                    ComboBoxHarmonics.IsEnabled = false;
                    break;
                case MonitorConstants.Parameter.EMG:
                    patient.setActiveParameters(patient.EMGFrequency, patient.EMGAmplitude, -1, patient.EMGLowAlarm, patient.EMGHighAlarm);
                    ComboBoxHarmonics.IsEnabled = false;
                    break;
                case MonitorConstants.Parameter.Resp:
                    patient.setActiveParameters(patient.RespFrequency, patient.RespAmplitude, -1, patient.RespLowAlarm, patient.RespHighAlarm);
                    ComboBoxHarmonics.IsEnabled = false;
                    break;
                default:
                    break;
            }

            // Update UI elements
            sliderECG.Value = patient.ActiveAmplitude;
            TextBoxFrequency.Text = patient.ActiveFrequency.ToString();
            lowAlarmTextBox.Text = patient.ActiveLowAlarm.ToString();
            highAlarmTextBox.Text = patient.ActiveHighAlarm.ToString();

            // Update displayed alarms
            DisplayAlarmLowLabel.Content = patient.DisplayedLowAlarm;
            DisplayAlarmHighLabel.Content = patient.DisplayedHighAlarm;
        }


        private void comboBoxParameters_IsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            ComboBox combo = sender as ComboBox;
            if (combo.IsEnabled)
                combo.SelectionChanged += comboBoxParameters_SelectionChanged;
            else
                combo.SelectionChanged -= comboBoxParameters_SelectionChanged;
        }

        private void buttonStartParameter_IsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
        {

        }

        private void buttonLoadImage_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ImageBrush MyImageBrush = new ImageBrush();
            // Create an OpenFileDialog 
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image files (*.bmp;*.jpg;*.jpeg;*.png)|*.bmp;*.jpg;*.jpeg;*.png|All files (*.*)|*.*";
            openFileDialog.InitialDirectory = System.IO.Path.Combine(Environment.CurrentDirectory, "Photos");

            // Show the dialog and check if the result is OK 
            if (openFileDialog.ShowDialog() == true)
            {
                // Create a new BitmapImage 
                BitmapImage bitmap = new BitmapImage();

                // Set the UriSource to load the image from the file 
                bitmap.BeginInit();
                bitmap.UriSource = new Uri(openFileDialog.FileName, UriKind.Absolute);
                bitmap.CacheOption = BitmapCacheOption.OnLoad; // Cache option to ensure the file can be accessed immediately
                bitmap.EndInit();

                // Set the ImageSource of the ImageBrush 
                MyImageBrush.ImageSource = bitmap;
                BildViereck.Fill = MyImageBrush;
            }
        }

        private void highAlarmTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !int.TryParse(e.Text, out int result);
        }

        private void lowAlarmTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !int.TryParse(e.Text, out int result);
        }

        /* private void highAlarmTextBox_TextChanged(object sender, TextChangedEventArgs e)
         {
             if (patient == null) return;

             // Versuche, den eingegebenen Wert in eine Zahl zu konvertieren
             if (int.TryParse(highAlarmTextBox.Text, out int highAlarmValue))
             {
                 // Überprüfe, ob der Wert innerhalb des zulässigen Bereichs liegt
                 if (highAlarmValue >= 0 && highAlarmValue <= 150)
                 {
                     // Setze den High Alarm-Wert für den Patienten
                     patient.HighAlarm(parameter, highAlarmValue);
                     DisplayAlarmLow.Content = patient.DisplayedLowAlarm;
                     DisplayAlarmHigh.Content = patient.DisplayedHighAlarm;
                     Console.WriteLine($"[DEBUG] High Alarm Wert geändert: {highAlarmValue}");
                 }
                 else
                 {
                     MessageBox.Show("Value must be between 0 and 150 Hz.");
                 }
             }
             else
             {
                 MessageBox.Show("Invalid input. Please enter a numerical value.");
             }
         }
         private void lowAlarmTextBox_TextChanged(object sender, TextChangedEventArgs e)
         {
             if (patient == null) return;
             {
                 int parameterLow = 0;
                 bool isValidLow;
                 isValidLow = int.TryParse(lowAlarmTextBox.Text, out parameterLow);

                 parameterLow = isValidLow ? parameterLow : 0;

                 // Versuche, den eingegebenen Wert in eine Zahl zu konvertieren
                 if (int.TryParse(lowAlarmTextBox.Text, out int lowAlarmValue))
                 {
                     // Überprüfe, ob der Wert innerhalb des zulässigen Bereichs liegt
                     if (lowAlarmValue >= 0 && lowAlarmValue <= 150)
                     {
                         // Setze den High Alarm-Wert für den Patienten
                         patient.LowAlarm(parameter, lowAlarmValue);
                         DisplayAlarmLow.Content = patient.DisplayedLowAlarm;
                         // DisplayAlarmHigh.Content = patient.DisplayedHighAlarm;
                         Console.WriteLine($"[DEBUG] Low Alarm Wert geändert: {lowAlarmValue}");
                     }
                     else
                     {
                         MessageBox.Show("Value must be between 0 and 150 Hz.");
                     }
                 }
                 else
                 {
                     MessageBox.Show("Invalid input. Please enter a numerical value.");
                 }
             }

         } */

        private void highAlarmTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
           // if (patient == null) return;

            // Versuche, den eingegebenen Wert in eine Zahl zu konvertieren
            if (int.TryParse(highAlarmTextBox.Text, out int highAlarmValue))
            {
                // Überprüfe, ob der Wert innerhalb des zulässigen Bereichs liegt
                if (highAlarmValue >= 0 && highAlarmValue <= 150)
                {
                    // Setze den High Alarm-Wert für den Patienten
                    patient.HighAlarm(parameter, highAlarmValue);
                    DisplayAlarmLowLabel.Content = patient.DisplayedLowAlarm;
                    DisplayAlarmHighLabel.Content = patient.DisplayedHighAlarm;
                    //MessageBox.Show($"[DEBUG] High Alarm Wert geändert: {highAlarmValue}");
                }
                else
                {
                    MessageBox.Show("Value must be between 0 and 150 Hz.");
                }
            }
            else
            {
                MessageBox.Show("Invalid input. Please enter a numerical value.");
            }
        }
        private void lowAlarmTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (patient == null) return;

            // Versuche, den eingegebenen Wert in eine Zahl zu konvertieren
            if (int.TryParse(lowAlarmTextBox.Text, out int lowAlarmValue))
            {
                // Überprüfe, ob der Wert innerhalb des zulässigen Bereichs liegt
                if (lowAlarmValue >= 0 && lowAlarmValue <= 150)
                {
                    // Setze den High Alarm-Wert für den Patienten
                    patient.LowAlarm(parameter, lowAlarmValue);
                    DisplayAlarmLowLabel.Content = patient.DisplayedLowAlarm;
                    DisplayAlarmHighLabel.Content = patient.DisplayedHighAlarm;
                    Console.WriteLine($"[DEBUG] Low Alarm Wert geändert: {lowAlarmValue}");
                }
                else
                {
                    MessageBox.Show("Value must be between 0 and 150 Hz.");
                }
            }
            else
            {
                MessageBox.Show("Invalid input. Please enter a numerical value.");
            }
        }
    }
}
